
 <script src="<?php echo base_url(); ?>support_assets/js/jquery.min.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/bootstrap.min.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/jquery-ui.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/jquery.validate.min.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/jquery.dataTables.min.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/dataTables.bootstrap4.min.js"></script>

 <script src="<?php echo base_url(); ?>support_assets/js/main.js"></script> 
 <script src="<?php echo base_url(); ?>support_assets/vendors/js/vendor.bundle.base.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/vendors/js/vendor.bundle.addons.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/off-canvas.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/misc.js"></script>
 <script src="<?php echo base_url(); ?>support_assets/js/dashboard.js"></script>
 <style>
  .table th img, .table td img {
    width: 100%;
    height: unset;
    border-radius: unset;
}
 </style>
