	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/chart.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap-table.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.event.move.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/responsive-slider.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery-ui.js"></script>
					